#!/bin/sh
java -Xmx3G -Xms2G -jar Hexxit.jar nogui