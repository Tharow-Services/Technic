#!/bin/sh
java -Dlog4j.configurationFile=log4j2_server.xml -Xmx3G -Xms2G -jar Hexxit.jar nogui